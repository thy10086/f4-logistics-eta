"""Check the official F4 test predictions and rescore the local backtests."""

import argparse
import csv
import hashlib
import io
import math
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import BadZipFile, ZipFile


TEST_ROWS = 911_415
VALIDATION_WINDOWS = (
    ("stress", "09/04–09/11 完整回测"),
    ("stress_audit", "09/04–09/11 预留样本"),
    ("hold", "09/12–09/20 完整回测"),
    ("hold_audit", "09/12–09/20 预留样本"),
)
SCORE_KEYS = ("ME", "B", "A", "pen_ontime", "pen_severe")


def member_path(archive, relative):
    matches = [name for name in archive.namelist() if name == relative or name.endswith("/" + relative)]
    if len(matches) != 1:
        raise ValueError(f"F4.zip 中应恰好有一份 {relative}，实际找到 {len(matches)} 份。")
    return matches[0]


def prediction_ids(path):
    ids = set()
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = csv.reader(stream)
        if next(rows, None) != ["pkg_no", "pred_hours"]:
            raise ValueError("预测 CSV 的列名应为 pkg_no,pred_hours。")
        for line, row in enumerate(rows, start=2):
            if len(row) != 2 or not row[0]:
                raise ValueError(f"预测 CSV 第 {line} 行应包含包裹编号与承诺小时数。")
            package, hours = row
            if package in ids:
                raise ValueError(f"预测 CSV 第 {line} 行有重复的 pkg_no。")
            try:
                value = float(hours)
            except ValueError as error:
                raise ValueError(f"预测 CSV 第 {line} 行的 pred_hours 不是数值。") from error
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"预测 CSV 第 {line} 行的 pred_hours 须为有限正数。")
            ids.add(package)
    return ids


def verify_test_predictions(archive, prediction):
    remaining = prediction_ids(prediction)
    member = member_path(archive, "data/test_202609.csv")
    with archive.open(member) as binary, io.TextIOWrapper(binary, encoding="utf-8-sig", newline="") as stream:
        rows = csv.reader(stream)
        columns = next(rows, [])
        if "pkg_no" not in columns:
            raise ValueError("正式测试集缺少 pkg_no 列。")
        id_index = columns.index("pkg_no")
        count = 0
        for line, row in enumerate(rows, start=2):
            if len(row) != len(columns):
                raise ValueError(f"正式测试集第 {line} 行的列数有误。")
            package = row[id_index]
            if package not in remaining:
                raise ValueError(f"正式测试集第 {line} 行的包裹无对应预测，或测试集编号重复。")
            remaining.remove(package)
            count += 1
    if remaining:
        raise ValueError(f"预测包含 {len(remaining):,} 个正式测试集外的包裹编号。")
    if count != TEST_ROWS:
        raise ValueError(f"正式测试集预期 {TEST_ROWS:,} 行，实际为 {count:,} 行。")
    return count, len(columns), "y_total_hours" in columns


def rescore(scorer, run_dir):
    env = dict(os.environ, PYTHONUTF8="1", OPENBLAS_NUM_THREADS="1")
    local_deps = run_dir / "python-deps"
    if local_deps.is_dir():
        deps = [str(local_deps)]
        if env.get("PYTHONPATH"):
            deps.append(env["PYTHONPATH"])
        env["PYTHONPATH"] = os.pathsep.join(deps)

    print("\n[带标签的本地回测 | 题包 score.py]", flush=True)
    for case, label in VALIDATION_WINDOWS:
        truth = run_dir / "check" / f"{case}_truth.csv"
        prediction = run_dir / "check" / f"{case}_prediction.csv"
        for path in (truth, prediction):
            if not path.is_file():
                raise ValueError(f"缺少 {path}，请用已经完成一次复现的 f4-local-run 目录。")
        completed = subprocess.run(
            [sys.executable, str(scorer), "--truth", str(truth), "--pred", str(prediction)],
            env=env, capture_output=True, encoding="utf-8",
        )
        if completed.returncode:
            raise ValueError(f"{label}评分失败\n{completed.stderr.strip() or completed.stdout.strip()}")
        scores = dict(line.strip().split(maxsplit=1) for line in completed.stdout.splitlines() if line.strip())
        if not all(key in scores for key in SCORE_KEYS):
            raise ValueError(f"{label}的官方评分脚本没有返回完整指标。")
        print(label, flush=True)
        print("  " + "  |  ".join(f"{key}={scores[key]}" for key in SCORE_KEYS), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kit", required=True, type=Path, help="官方 F4.zip 路径")
    parser.add_argument("--run-dir", required=True, type=Path, help="已完成复现的 f4-local-run 目录")
    args = parser.parse_args()
    run_dir = args.run_dir.resolve()
    prediction = run_dir / "result" / "prediction.csv"

    try:
        with ZipFile(args.kit) as archive:
            print("[正式测试集 | F4.zip 中的 data/test_202609.csv]", flush=True)
            count, columns, has_label = verify_test_predictions(archive, prediction)
            print(f"包裹编号及预测值校验通过，{count:,} 行，测试集 {columns} 列。", flush=True)
            print("实际签收时长列 y_total_hours " + ("存在。" if has_label else "缺失，正式分数由主办方计算。"), flush=True)
            scorer_source = archive.read(member_path(archive, "tools/score.py"))
        with prediction.open("rb") as stream:
            checksum = hashlib.file_digest(stream, "sha256").hexdigest()
        print(f"预测 SHA-256  {checksum}", flush=True)

        with TemporaryDirectory(prefix="f4-score-", dir=run_dir) as temporary:
            scorer = Path(temporary) / "score.py"
            scorer.write_bytes(scorer_source)
            rescore(scorer, run_dir)
    except (BadZipFile, OSError, ValueError) as error:
        print(f"检查失败  {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
