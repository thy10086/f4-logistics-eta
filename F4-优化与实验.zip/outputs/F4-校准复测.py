"""Recompute the frozen F4 calibration experiments against the released results."""

import argparse
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
from shutil import copyfile
import subprocess
import sys
from tempfile import mkdtemp
from zipfile import BadZipFile, ZipFile


ROOT = Path(__file__).resolve().parent.parent
MODES = (
    ("主实验", "", ()),
    ("冻结锚点对照", "fixed-anchor", ("--freeze-anchor",)),
    ("同 v3 底座小幅调整", "v3-adjusted", ("--v3-adjusted",)),
)
TABLES = ("window-metrics.csv", "carrier-metrics.csv", "cross-date-ranking.csv")


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def equal_cell(left, right):
    if left == right:
        return True
    try:
        return math.isclose(float(left), float(right), abs_tol=1e-8, rel_tol=0)
    except (ValueError, TypeError):
        return False


def verify_csv(benchmark, path):
    expected = csv.DictReader(io.StringIO(benchmark.decode("utf-8-sig"), newline=""))
    with path.open(encoding="utf-8-sig", newline="") as stream:
        actual = csv.DictReader(stream)
        if expected.fieldnames != actual.fieldnames:
            raise ValueError(f"{path.name} 的字段与实验包不一致。")
        count = 0
        for line, pair in enumerate(zip(expected, actual, strict=True), start=2):
            count += 1
            left, right = pair
            for key, value in left.items():
                if not equal_cell(value, right[key]):
                    raise ValueError(f"{path.name} 第 {line} 行 {key} 与实验包不一致，预期 {value}，实际 {right[key]}。")
    return count


def show_baseline(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        results = {(row["window"], row["strategy"]): row for row in csv.DictReader(stream)}
    print("\n[已用原版 score.py 重算的旧窗口对照]", flush=True)
    for window, label in (("stress", "09/04–09/11"), ("hold", "09/12–09/20")):
        for key, name in (("v3_current", "v3 原版"), ("v3_minus10", "统一减 10 小时")):
            row = results[window, key]
            print(f"{label}  {name:<10}  ME={float(row['ME']):.4f}  "
                  f"准时罚分={float(row['pen_ontime']):.4f}  严重罚分={float(row['pen_severe']):.4f}  "
                  f"B={float(row['B']):.4f}  A={float(row['A']):.4f}", flush=True)


def retest(workspace):
    project = workspace / "work/f4-local-repro"
    source = workspace / "work/f4-calibration-exp/extra"
    run = project / "f4-local-run"
    prediction = run / "result/prediction.csv"
    archive_path = workspace / "outputs/F4-承诺校准实验.zip"
    work = workspace / "work"

    with ZipFile(archive_path) as archive:
        integrity = json.loads(archive.read("results/integrity.json"))
        original_sha = integrity["original_prediction_sha256"]
        if sha256(prediction) != original_sha:
            raise ValueError("本地 v3 预测的 SHA-256 与实验使用的原版不同。")
        folder = Path(mkdtemp(prefix="f4-calibration-retest-", dir=work))
        print(f"复测结果目录  {folder}", flush=True)

        code = folder / "code"
        code.mkdir()
        for script in ("evaluate.py", "calibration.py", "prepare_folds.py"):
            (code / script).write_bytes(archive.read(f"code/{script}"))
        for relative, expected in zip((Path("locked-policy.json"), Path("v3-adjusted/locked-policy.json")),
                                      integrity["policy_sha256"], strict=True):
            contents = archive.read("results/" + relative.as_posix())
            if hashlib.sha256(contents).hexdigest() != expected:
                raise ValueError(f"实验包内的策略校验失败  {relative}")
            path = folder / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(contents)
        for model in ("original", "history"):
            cached = source / model / "fresh.npz"
            if not cached.is_file():
                raise FileNotFoundError(f"缺少日期回测缓存 {cached}。可按实验包 README 运行 prepare_folds.py 生成。")
            destination = folder / "extra" / model / "fresh.npz"
            destination.parent.mkdir(parents=True, exist_ok=True)
            copyfile(cached, destination)

        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", OPENBLAS_NUM_THREADS="1")
        project_deps = str(run / "python-deps")
        env["PYTHONPATH"] = os.pathsep.join(filter(None, (project_deps, env.get("PYTHONPATH"))))
        rows = {}
        for label, subdir, flags in MODES:
            print(f"\n[重算 {label}]", flush=True)
            mode_folder = folder / subdir
            mode_folder.mkdir(parents=True, exist_ok=True)
            completed = subprocess.run(
                [sys.executable, "-X", "utf8", "-u", str(code / "evaluate.py"),
                 "--project", str(project), "--experiment", str(folder), *flags],
                env=env, capture_output=True, encoding="utf-8",
            )
            (mode_folder / "retest.log").write_text(completed.stdout + completed.stderr, encoding="utf-8")
            if completed.returncode:
                raise ValueError(completed.stderr.strip() or completed.stdout.strip() or f"{label}复测失败。")
            current = {}
            for name in TABLES:
                relative = Path(subdir) / name
                current[name] = verify_csv(archive.read("results/" + relative.as_posix()), folder / relative)
            rows[label] = current
            print(f"PASS  {current['window-metrics.csv']} 条窗口评分，{current['carrier-metrics.csv']} 条逐商明细与实验包一致。", flush=True)

    if sha256(prediction) != original_sha:
        raise ValueError("复测期间原版预测文件校验值发生变化。")
    show_baseline(folder / "window-metrics.csv")
    verification = dict(result="PASS", original_prediction_sha256=original_sha, matching_rows=rows)
    (folder / "retest-verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"\nPASS  三组复测通过，原 v3 预测的 SHA-256 一致。\n结果目录  {folder}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=ROOT, help="包含 outputs 和 work 的工作区目录")
    args = parser.parse_args()
    try:
        retest(args.workspace.resolve())
    except (BadZipFile, KeyError, OSError, ValueError) as error:
        print(f"复测失败  {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
