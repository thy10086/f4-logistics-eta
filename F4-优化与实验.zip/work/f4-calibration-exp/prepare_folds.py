"""Fit the extra F4 time window using the project's existing model code."""

import argparse
from pathlib import Path
import sys


FREEZE = "2026-08-29"
EXTRA_END = "2026-09-04"


def locate(project):
    run = project / "f4-local-run"
    matches = sorted(path.parent for path in (run / "cache").glob("*/features.duckdb")
                     if (path.parent / "original" / "hold.npz").is_file()
                     and (path.parent / "history" / "hold.npz").is_file())
    if len(matches) != 1:
        raise ValueError(f"Expected one fitted v3 cache in {run}, found {len(matches)}")
    return run, matches[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--experiment", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    project = args.project.resolve()
    _, cache = locate(project)
    sys.path.insert(0, str(project))
    import duckdb
    import history_model
    import matched

    original = args.experiment / "extra" / "original"
    history = args.experiment / "extra" / "history"
    original.mkdir(parents=True, exist_ok=True)
    history.mkdir(parents=True, exist_ok=True)
    with duckdb.connect(str(cache / "features.duckdb"), read_only=True,
                        config={"threads": 6, "memory_limit": "2GB"}) as db:
        matched.fit_split(db, original, "fresh", FREEZE, EXTRA_END, 6, 240)
        snapshots = [history_model.build_snapshot(*history_model.load_series(db, key))
                     for key in history_model.ENTITY_SQL]
        history_model.run_split(db, history, "fresh", FREEZE, EXTRA_END, snapshots, 6, 240)


if __name__ == "__main__":
    main()
