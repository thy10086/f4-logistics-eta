"""Break down the calibration windows and the two priority carriers."""

import argparse
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

from calibration import apply_policy, import_project, official_module, periods, protect_floor
from evaluate import archived_predictions, score_one
from prepare_folds import locate


def run(project, experiment, v3_adjusted):
    duckdb, matched, release = import_project(project)
    import carrier_policy
    import solution as core

    run_dir, cache = locate(project)
    scorer = official_module(cache)
    output = experiment / "v3-adjusted" if v3_adjusted else experiment
    locked = json.loads((output / "locked-policy.json").read_text(encoding="utf-8"))
    old_rules = json.loads((run_dir / "check/summary.json").read_text(encoding="utf-8"))["by_carrier"] if v3_adjusted else None
    calibration_rows, sensitivities = [], []
    with duckdb.connect(str(cache / "features.duckdb"), read_only=True, config={"threads": 6, "memory_limit": "2GB"}) as db:
        calibration, _ = periods(db, matched, release, experiment / "extra", old_rules)
        for period in calibration:
            truth = SimpleNamespace(y=period.y, carrier_text=np.array([f"LSP_{g:04d}" for g in period.group]))
            for name, policy in locked["strategies"].items():
                prediction, offsets = apply_policy(period.base, period.floor, period.group, period.risk, policy)
                _, group_rows = score_one(period.key, "signed_calibration", name, period.known, truth, prediction,
                                          period.base, period.base, offsets, period.floor.astype(float), scorer, core)
                for row in group_rows:
                    row.pop("mean_change_vs_v3")
                calibration_rows.extend(group_rows)

        windows = {} if v3_adjusted else carrier_policy.WINDOWS
        for window, dates in windows.items():
            truth = core.range_frame(db, dates)
            v3 = archived_predictions(run_dir, window, truth)
            floors = truth.duration_floor.astype(float)
            before = scorer.score(truth.carrier_text, truth.y, v3)
            for group in ("LSP_0004", "LSP_0006"):
                mask = truth.carrier_text == group
                changed = v3.copy()
                changed[mask] = protect_floor(v3[mask] - 10, floors[mask])
                score = scorer.score(truth.carrier_text, truth.y, changed)
                residual = truth.y[mask] - changed[mask]
                sensitivities.append(dict(window=window, carrier=group, n=int(mask.sum()), share=float(mask.mean()),
                                          configured_delta_hours=-10, actual_delta_hours=float((changed[mask] - v3[mask]).mean()),
                                          r=float(np.mean(residual <= 0)), s=float(np.mean(residual > 24)),
                                          change_me=float(score["ME"] - before["ME"]), change_a=float(score["A"] - before["A"]), **score))
    pd.DataFrame(calibration_rows).to_csv(output / "calibration-carriers.csv", index=False)
    if sensitivities:
        pd.DataFrame(sensitivities).to_csv(experiment / "v3-carrier-sensitivity.csv", index=False)
        print(pd.DataFrame(sensitivities).to_string(index=False), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--experiment", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--v3-adjusted", action="store_true")
    args = parser.parse_args()
    run(args.project.resolve(), args.experiment.resolve(), args.v3_adjusted)


if __name__ == "__main__":
    main()
