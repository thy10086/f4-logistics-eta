"""Evaluate locked F4 calibration candidates and the archived v3 baseline."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
import pandas as pd

from calibration import anchor, apply_policy, base_prediction, import_project, load_cached, official_module, protect_floor
from prepare_folds import EXTRA_END, FREEZE, locate


EARLY = (FREEZE, "2026-09-01")
LATE = ("2026-09-01", EXTRA_END)
V3 = "v3_current"
MINUS = "v3_minus10"
BASE = "asof_anchor"


def archived_predictions(run, name, truth):
    archived = pd.read_csv(run / "check" / f"{name}_prediction.csv", dtype={"pkg_no": str})
    if not np.array_equal(archived["pkg_no"].to_numpy(), truth.ids):
        raise ValueError(f"Archived v3 predictions have different package IDs for {name}")
    return archived["pred_hours"].to_numpy()


def historical_v3_replay(source, package, policies, carrier_policy):
    variants, _ = carrier_policy.forecasts(source / "original", source / "history", "fresh")
    values = np.empty(len(package["y"]))
    recipes = {}
    for group, rule in policies.items():
        recipe = carrier_policy.Candidate(rule["history_weight"], rule["tail_scale"], rule["rule"])
        if recipe not in recipes:
            ref, target = variants[recipe.history_weight]
            recipes[recipe] = carrier_policy.carrier_base(ref, target, carrier_policy.matched.day(FREEZE), recipe)
        take = package["carrier"] == int(group)
        values[take] = recipes[recipe][take] + rule["buffer"]
    if set(map(int, policies)) != set(np.unique(package["carrier"])):
        raise ValueError("The archived v3 settings do not cover the added window")
    return protect_floor(values, package["floor"])


def score_one(scope, category, candidate, subset, truth, values, anchor_values, v3_values, adjustment, floors, scorer, core):
    prediction = values[subset]
    actual = truth.y[subset]
    groups = truth.carrier_text[subset]
    asof = anchor_values[subset]
    archived = v3_values[subset]
    score = scorer.score(groups, actual, prediction)
    local, by_group = core.evaluate(actual, prediction, groups)
    if any(not np.isclose(local[key], official, atol=1e-9, rtol=0) for key, official in score.items()):
        raise ValueError(f"Scorer verification failed for {scope}/{candidate}")
    floor_violations = int(np.count_nonzero(prediction < floors[subset]))
    if candidate != V3 and floor_violations:
        raise ValueError(f"A promise fell below its package floor in {scope}/{candidate}")
    metadata = {"window": scope, "scope": category, "strategy": candidate}
    result = dict(**metadata, n=len(actual), **score, prediction_mean=local["promise_hours"], actual_mean=local["actual_hours"],
                  carriers_at_90=local["carriers_at_90"], carriers_at_3=local["carriers_at_3"],
                  floor_violations=floor_violations)
    detail = []
    for group in by_group.itertuples(index=False):
        members = groups == group.carrier
        rows = int(members.sum())
        carrier_summary = group._asdict()
        carrier_summary.pop("n")
        configured = adjustment[subset][members]
        detail.append(dict(**metadata, **carrier_summary, n=rows, share=rows / len(actual),
                           prediction_mean=float(prediction[members].mean()), actual_mean=float(actual[members].mean()),
                           requested_offset_mean=float(configured.mean()), requested_offset_min=float(configured.min()),
                           requested_offset_max=float(configured.max()),
                           mean_change_vs_anchor=float((prediction[members] - asof[members]).mean()),
                           mean_change_vs_v3=float((prediction[members] - archived[members]).mean()),
                           floor_rows=int(np.count_nonzero(prediction[members] <= np.ceil(floors[subset][members] * 10000) / 10000))))
    return result, detail


def evaluate_window(db, name, dates, cut_date, source, scopes, run, policies, old_rules, mods, frozen_anchor, use_v3):
    matched, release, carrier_policy, core, scorer = mods
    _, _, anchoring, n_train = anchor(db, matched, release, source, name, cut_date)
    forecast, rows = load_cached(source, name, "eval")
    truth = core.range_frame(db, dates)
    if (rows != n_train or not np.array_equal(forecast["y"], truth.y)
            or not np.array_equal(forecast["carrier"], truth.carrier)
            or not np.array_equal(forecast["floor"], truth.duration_floor)):
        raise ValueError(f"Cache and true validation data are misaligned for {name}")
    if not np.isfinite(truth.y).all() or not np.all(forecast["pay_day"] >= matched.day(cut_date)):
        raise ValueError(f"Wrong time or incomplete ground-truth labels for {name}")

    v3 = (historical_v3_replay(source, forecast, old_rules, carrier_policy) if name == "fresh"
          else archived_predictions(run, name, truth))
    baseline = v3 if use_v3 else base_prediction(forecast, frozen_anchor if frozen_anchor is not None else anchoring, release)
    floor = forecast["floor"].astype(np.float64)
    risk = forecast["q97"] - forecast["q90"]
    fixed = {V3: (v3, np.zeros_like(floor)), MINUS: (protect_floor(v3 - 10, floor), np.full_like(floor, -10))}
    if not use_v3:
        fixed[BASE] = (baseline, np.zeros_like(floor))
    fixed.update({key: apply_policy(baseline, floor, forecast["carrier"], risk, policy)
                  for key, policy in policies.items()})

    result, carriers, populations = [], [], []
    for scope, category, mask in scopes:
        populations.append(dict(window=scope, scope=category, training_cutoff=cut_date, training_rows=n_train,
                                validation_rows=int(mask.sum()),
                                signed_after_training_cutoff=int(np.count_nonzero(mask & (forecast["sign_day"] >= matched.day(cut_date))))))
        for candidate, (hours, notes) in fixed.items():
            metrics, detail = score_one(scope, category, candidate, mask, truth, hours, baseline, v3, notes, floor, scorer, core)
            result.append(metrics)
            carriers.extend(detail)
        print(scope + ": " + ", ".join(f"{row['strategy']}={row['A']:.4f}" for row in result if row["window"] == scope), flush=True)
    return result, carriers, populations


def ranking(scores):
    ranking_rows = []
    for strategy, variants in scores.groupby("strategy", sort=False):
        fresh = variants[variants["scope"] == "locked_date"]
        previous = variants[variants["scope"] == "v3_reused_date"]
        overall = pd.concat([fresh, previous])
        total_penalty = overall["pen_ontime"] + overall["pen_severe"]
        ranking_rows.append(dict(strategy=strategy, fresh_mean_a=fresh.A.mean(), fresh_worst_a=fresh.A.max(),
                                 old_mean_a=previous.A.mean(), old_worst_a=previous.A.max(),
                                 all_mean_a=overall.A.mean(), all_worst_a=overall.A.max(),
                                 all_max_penalty=total_penalty.max(), all_mean_penalty=total_penalty.mean(),
                                 zero_windows=int((total_penalty <= 1e-9).sum()),
                                 average_worst_objective=.7 * overall.A.mean() + .3 * overall.A.max()))
    return pd.DataFrame(ranking_rows).sort_values(["average_worst_objective", "all_max_penalty", "fresh_worst_a"])


def evaluate(project, experiment, freeze_anchor, v3_adjusted):
    duckdb, matched, release = import_project(project)
    import solution as core
    import carrier_policy

    run, cache = locate(project)
    scorer = official_module(cache)
    output = experiment / "v3-adjusted" if v3_adjusted else experiment / "fixed-anchor" if freeze_anchor else experiment
    lock = (output if v3_adjusted else experiment) / "locked-policy.json"
    config = json.loads(lock.read_text(encoding="utf-8"))
    if config["freeze"] != FREEZE or config["scorer_sha256"] != sha256((cache / "official/tools/score.py").read_bytes()).hexdigest():
        raise ValueError("The policy lock or official scorer does not match the calibration run")
    if v3_adjusted and config.get("base") != "published_v3":
        raise ValueError("The lock is missing the published v3 baseline designation")
    old_rules = json.loads((run / "check/summary.json").read_text(encoding="utf-8"))["by_carrier"]
    output.mkdir(parents=True, exist_ok=True)

    rows, groups, populations = [], [], []
    with duckdb.connect(str(cache / "features.duckdb"), read_only=True, config={"threads": 6, "memory_limit": "2GB"}) as db:
        frozen = None
        if freeze_anchor:
            _, _, frozen, _ = anchor(db, matched, release, experiment / "extra", "fresh", FREEZE)
            (output / "fixed-anchor.json").write_text(json.dumps(dict(
                freeze=FREEZE, policy_sha256=sha256(lock.read_bytes()).hexdigest(), pooled=frozen[0], by_carrier=frozen[1]
            ), indent=2), encoding="utf-8")
        masks = carrier_policy.audit_masks(db)
        mods = (matched, release, carrier_policy, core, scorer)
        for key, dates, cut_date, path in (("fresh", (EARLY[0], LATE[1]), FREEZE, experiment / "extra"),
                                           ("stress", carrier_policy.WINDOWS["stress"], matched.STRESS_START, cache),
                                           ("hold", carrier_policy.WINDOWS["hold"], matched.HOLD_START, cache)):
            if key == "fresh":
                batch, _ = load_cached(path, "fresh", "eval")
                split = batch["pay_day"] < matched.day(LATE[0])
                scopes = [("0829_0831", "locked_date", split), ("0901_0903", "locked_date", ~split)]
                del batch
            else:
                scopes = [(key, "v3_reused_date", np.ones_like(masks[key])), (key + "_audit", "v3_hash_control", masks[key])]
            scored, detail, population = evaluate_window(db, key, dates, cut_date, path, scopes, run, config["strategies"], old_rules, mods, frozen, v3_adjusted)
            rows.extend(scored)
            groups.extend(detail)
            populations.extend(population)

    scores = pd.DataFrame(rows)
    for key, want in (("stress", 83.23024685613503), ("hold", 84.06571123623344), ("stress_audit", 83.05174936081873), ("hold_audit", 84.01410567415313)):
        got, = scores.loc[(scores["window"] == key) & (scores["strategy"] == V3), "A"]
        if not np.isclose(got, want, rtol=0, atol=1e-9):
            raise ValueError(f"Archived result changed in {key}")
    for key, want in (("stress", 76.556708), ("hold", 76.843674)):
        got, = scores.loc[(scores["window"] == key) & (scores["strategy"] == MINUS), "A"]
        if abs(got - want) > .000001:
            raise ValueError(f"10-hour reference changed in {key}")
    scores.to_csv(output / "window-metrics.csv", index=False)
    pd.DataFrame(groups).to_csv(output / "carrier-metrics.csv", index=False)
    pd.DataFrame(populations).to_csv(output / "window-provenance.csv", index=False)
    comparison = ranking(scores)
    comparison.to_csv(output / "cross-date-ranking.csv", index=False)
    print(comparison.to_string(index=False), flush=True)
    print(f"Evaluation policy SHA-256: {sha256(lock.read_bytes()).hexdigest()}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--experiment", type=Path, default=Path(__file__).resolve().parent)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--freeze-anchor", action="store_true", help="also hold the Aug 29 anchor corrections unchanged")
    mode.add_argument("--v3-adjusted", action="store_true", help="audit bounded adjustments to the archived policy")
    args = parser.parse_args()
    evaluate(args.project.resolve(), args.experiment.resolve(), args.freeze_anchor, args.v3_adjusted)


if __name__ == "__main__":
    main()
