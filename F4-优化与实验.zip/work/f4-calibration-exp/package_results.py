"""Check the experiment artifacts and assemble the study deliverables."""

from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

import numpy as np
import pandas as pd


EXP = Path(__file__).resolve().parent
OUTPUT = EXP.parent.parent / "outputs"
ORDER = ("0829_0831", "0901_0903", "stress", "hold")
LABELS = {
    "v3_current": "v3 原版", "v3_minus10": "v3 统一 −10h", "asof_anchor": "仅时点锚定",
    "uniform_zero": "统一｜校准零罚", "uniform_min_a": "统一｜校准最小 A",
    "carrier_zero": "分商｜校准零罚", "carrier_min_a": "分商｜校准最小 A",
    "risk_zero": "分商加风险层｜校准零罚", "risk_min_a": "分商加风险层｜校准最小 A",
}


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def verify_results(folder):
    windows = pd.read_csv(folder / "window-metrics.csv")
    carriers = pd.read_csv(folder / "carrier-metrics.csv")
    expected_window_names = {*ORDER, "stress_audit", "hold_audit"}
    assert set(windows.window) == expected_window_names
    assert len(windows) == len(expected_window_names) * (8 if folder.name == "v3-adjusted" else 9)
    assert len(carriers) == 8 * len(windows)
    for row in windows.itertuples(index=False):
        actual = carriers.loc[(carriers.window == row.window) & (carriers.strategy == row.strategy)]
        assert len(actual) == 8 and actual.n.sum() == row.n
        assert np.isclose(actual.share.sum(), 1, rtol=0, atol=1e-12)
        assert row.floor_violations == 0 or row.strategy == "v3_current"
        assert np.isclose(row.ME, abs(row.prediction_mean - row.actual_mean), rtol=0, atol=1e-9)
        assert np.isclose(row.prediction_mean, np.dot(actual.share, actual.prediction_mean), rtol=0, atol=1e-9)
        assert np.isclose(row.actual_mean, np.dot(actual.share, actual.actual_mean), rtol=0, atol=1e-9)
        assert np.isclose(row.pen_ontime, actual.pen_ontime.sum(), rtol=0, atol=1e-9)
        assert np.isclose(row.pen_severe, actual.pen_severe.sum(), rtol=0, atol=1e-9)
        assert np.isclose(row.B, row.ME + row.pen_ontime, rtol=0, atol=1e-9)
        assert np.isclose(row.A, row.B + row.pen_severe, rtol=0, atol=1e-9)
    return windows


def summary_table(scored):
    view = scored.pivot(index="strategy", columns="window", values="A")
    rows = ["| 方案 | 8/29–31 | 9/01–03 | 9/04–11 | 9/12–20 | 最差 A |",
            "| --- | ---: | ---: | ---: | ---: | ---: |"]
    for key, label in LABELS.items():
        if key in view.index:
            values = [view.loc[key, window] for window in ORDER]
            rows.append(f"| {label} | " + " | ".join(f"{value:.2f}" for value in (*values, max(values))) + " |")
    return "\n".join(rows)


def main():
    original = json.loads((EXP / "original-sha256.json").read_text(encoding="utf-8"))
    for name, expected in original.items():
        assert digest(Path(name)) == expected, name
    primary = verify_results(EXP)
    frozen = verify_results(EXP / "fixed-anchor")
    v3 = verify_results(EXP / "v3-adjusted")

    locks = [EXP / "locked-policy.json", EXP / "v3-adjusted/locked-policy.json"]
    for folder in (EXP, EXP / "v3-adjusted"):
        pieces = pd.read_csv(folder / "calibration-carriers.csv")
        assert len(pieces) == 2 * 6 * 8 and pieces.groupby(["window", "strategy"]).share.sum().between(.999999999, 1.000000001).all()
        maturity = pd.read_csv(folder / "calibration-maturity.csv")
        lock = folder / "locked-policy.json"
        assert lock.stat().st_mtime < (folder / "window-metrics.csv").stat().st_mtime
        for group in maturity[maturity.risk_groups == 1].carrier.unique():
            candidate = json.loads(lock.read_text(encoding="utf-8"))["strategies"]["risk_zero"]
            edge = candidate["edges"][str(int(group.split("_")[-1]))]
            assert not edge

    expected_scorer = json.loads(locks[0].read_text(encoding="utf-8"))["scorer_sha256"]
    with ZipFile(Path(os.environ["F4_OFFICIAL_KIT"])) as archive:
        name, = [entry for entry in archive.namelist() if entry.endswith("/tools/score.py")]
        assert sha256(archive.read(name)).hexdigest() == expected_scorer
    report = f"""# F4 承诺校准实验报告

**正式提交继续使用 v3。** 使用早期数据锁定的独立校准候选里，统一零罚版跨日期最稳，但在四个完整评估窗口中仍产生了罚分。在原 v3 底座上小幅调整时，分商零罚版的四窗平均 A 从 **111.67 降到 108.25**，最差窗口 A 从 **148.38 降到 146.84**，代价是旧的两个零罚窗口新增严重超时罚分。这组对照适合判断优化方向，现有正式预测保留。

## 日期与评分口径

- **选参**使用 8 月 1–7 日、8–14 日付款的早期样本，按 8 月 29 日零点模拟锁定。基础模型训练使用 `sign_time < cutoff`。锚点与选参通过哈希在模型预留样本内再分开。候选分数只使用锁定时已签收的标签，分别是 **52,457 条**和 **48,936 条**。校准零罚候选还用未签收件当时的已等待时长下界约束已确定的超时风险。
- **新增评估**为 8 月 29–31 日和 9 月 1–3 日，分别有 **222,327 条**和 **295,286 条**。两个窗口共用一批按 8 月 29 日切分训练的 original/history 预测，每组训练 **2,042,907 条**。锁定完候选才加载评分日期窗的 `eval_*` 真值。两段标签完整保留。它们未参与本轮选参和 v3 定参，部分日期曾用于更早版本探索。
- **已有对照**为 9 月 4–11 日和 9 月 12–20 日，两组 original/history NPZ 直接复用。它们参与过 v3 策略选择。原版哈希预留仅作同日期对照。新增窗口中的 v3 分数是旧配置回放，旧配置曾使用更晚的标签，因此这些分数只作参考。
- **比较规则**在每个训练切点前使用可用签收信息估计锚点。统一、分商、分商加风险层三组改动共享相同底座。风险特征为 `P97−P90`。每个风险桶在两段选参样本中均须有至少 250 个已签收件，三桶不足时尝试两桶，再回退到服务商级。所有新预测保留逐包裹时效下限，写四位小数后仍满足下限。
- **优化目标**为两个选参窗口 `0.7 × 平均 A + 0.3 × 最差 A`。每个家族独立拟合校准零罚和校准最小 A 两类。主实验步长为 2 小时，范围 −100 至 +160 小时。用题包原版 `score.py` 的 `score()` 复核了所有窗口，并逐项与项目计算校对。下面的表是完整窗口，所有 ME、B、两项罚分和哈希预留均在 `window-metrics.csv` 中。

## 主实验结果

{summary_table(primary)}

校准期的分商和风险分层的零罚候选确实达到两项零罚。风险分层零罚候选的早期 A 为 **58.99、58.68**，后续新增窗口 A 升至 **518.01、518.26**。例如 LSP_0006 在分商零罚候选下，新增两窗严重超时率分别为 **10.11%、11.83%**。这个校准期优势未能迁移。

**锚点冻结复核。** 仅使用 8 月 29 日的锚点，后续两个已用日期的风险分层零罚 A 从 **352.45、331.00** 改为 **213.57、249.41**，新增两窗与主实验一致。锚点重估影响了结果，冻结后也不足以消除时间迁移风险。完整结果见 `fixed-anchor/`。

## 同一 v3 底座的小幅调整

这组敏感性检查复用已发布的 v3 底座，只用早期已签收记录选择 −12 至 +24 小时的改动，再锁定。旧底座的参数来自后段窗口，因此结果属于历史对照。

{summary_table(v3)}

- **分商｜校准零罚**按四窗平均 A 与最差 A 的加权目标排第一，四窗 A 均低于 v3。9 月两个完整窗的严重超时罚分分别为 **3.49、4.78**，最差窗口总罚分升至 **70.75**。四窗均没有同时清零。
- **风险层｜校准最小 A**是目标为最小 A 的调整家族里跨日期最好的，平均 A 为 **108.38**，最差 A 为 **147.80**，风险分层没有进一步降低分商零罚版的平均或最差 A。
- **统一｜校准零罚**选择加 **24 小时**，最差 A 降至 **130.63**，平均 A 升至 **118.13**。9 月旧窗口仍是零罚，新增两窗仍有严重超时罚分。它体现了降低最差风险与提高平均承诺之间的取舍。
- **v3 统一减 10 小时**在两个旧窗口 A 分别为 **76.5567、76.8437**，复现了预期，严重超时罚分分别为 **3.3265、2.7780**。在新增日期的 v3 回放中，A 升至 **149.56、180.52**。

## 两家重点服务商

**LSP_0006 的高占比放大了均值改动。** 它在 9 月两个旧窗口占 **50.81%、49.31%**。9 月 12–20 日，v3 对它的平均承诺是 **211.42 小时**，实际均值 **148.06 小时**，准时率 **94.87%**，严重超时率 **2.66%**。只缩短这家 10 小时，整体 ME 降 **4.93 小时**，严重超时率升到 **3.45%** 并产生 **2.27 分**罚分，严格 A 从 **84.0657** 降到 **81.4011**。它适合优先检查更细的风险辨别能力。

**LSP_0004 的大缓冲跟尾部约束有关。** v3 对它混合了两组模型，尾部权重为 **2.35**，在已有锚点上取两个窗口所需缓冲的较大值 **117.7409 小时**，另一窗为 **117.4213 小时**。在 9 月 12–20 日，它占 **2.66%**，平均承诺 **539.09 小时**，实际均值 **234.95 小时**，严重超时率 **2.58%**。只减这家 10 小时，严重超时率为 **2.73%**，整体 ME 只降 **0.27 小时**。早期第二校准窗在锁定时仍有 **7.41%** 未签收。主实验的分商和风险零罚规则在不同底座上均触及 **−100 小时**搜索边界，8 月 29–31 日后续完整标签下，这家的严重超时率达到 **17.49%**。两个缓冲基准不同，实际预测变化以逐商表的 `mean_change_vs_v3` 为准。

## 交付核验

原项目源码和两份原预测文件用实验前的 SHA-256 逐一复核一致。实验包包括可复现脚本、已锁定参数、评分表和逐服务商表。比赛 `score.py` 的 SHA-256 为 `{expected_scorer}`。
"""
    report_path = OUTPUT / "F4-承诺校准实验报告.md"
    report_path.write_text(report, encoding="utf-8")
    files = {f"code/{name}": EXP / name for name in ("prepare_folds.py", "calibration.py", "evaluate.py", "diagnostics.py")}
    files["README.md"] = EXP / "复现实验.md"
    files["实验报告.md"] = report_path
    for relative in (".", "fixed-anchor", "v3-adjusted"):
        folder = EXP / relative
        for path in folder.iterdir():
            if path.is_file() and path.suffix in (".csv", ".json") and path.name != "original-sha256.json":
                files[(Path("results") / relative / path.name).as_posix()] = path
    archive = OUTPUT / "F4-承诺校准实验.zip"
    temp = archive.with_suffix(".tmp.zip")
    proof = {"unchanged_files": len(original), "original_prediction_sha256": original[next(key for key in original if key.endswith("F4-prediction-v3.csv"))],
             "scorer_sha256": expected_scorer, "policy_sha256": [digest(path) for path in locks],
             "score_rows": {"primary": len(primary), "fixed": len(frozen), "v3_sensitivity": len(v3)}}
    with ZipFile(temp, "w", ZIP_DEFLATED) as bundle:
        for name, path in files.items():
            bundle.write(path, name)
        bundle.writestr("results/integrity.json", json.dumps(proof, indent=2) + "\n")
    with ZipFile(temp) as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist()) == {*files, "results/integrity.json"}
        for name, path in files.items():
            assert bundle.read(name) == path.read_bytes()
            if name.endswith(".py"):
                compile(bundle.read(name), name, "exec")
    temp.replace(archive)
    print(json.dumps(proof, indent=2))
    print(report_path, archive, sep="\n")


if __name__ == "__main__":
    main()
