"""Fit calendar-separated F4 calibration adjustments without future labels."""

import argparse
from dataclasses import dataclass
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy.optimize import Bounds, LinearConstraint, milp

from prepare_folds import FREEZE, locate


CALENDAR = (("cal_0801_0807", "2026-08-01", "2026-08-08"),
            ("cal_0808_0814", "2026-08-08", "2026-08-15"))
OFFSETS = np.arange(-100, 162, 2)
V3_OFFSETS = np.arange(-12, 26, 2)
MIN_SEGMENT = 250
WORST_WEIGHT = .30
GATE = (.10, .03)


def import_project(project):
    sys.path.insert(0, str(project))
    import duckdb
    import matched
    import release
    return duckdb, matched, release


def official_module(cache):
    path = cache / "official" / "tools" / "score.py"
    spec = importlib.util.spec_from_file_location("f4_official_score", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_cached(folder, name, section, history_weight=.5):
    variants = []
    prefix = section + "_"
    for model in ("original", "history"):
        with np.load(folder / model / f"{name}.npz") as record:
            values = {key[len(prefix):]: record[key] for key in record.files if key.startswith(prefix)}
            variants.append((values, int(record["training_rows"])))
    (original, training_rows), (history, history_rows) = variants
    if training_rows != history_rows or set(original) != set(history) or any(
        not np.array_equal(original[key], history[key]) for key in original if key not in ("q90", "q97")
    ):
        raise ValueError(f"Unaligned model caches for {name}/{section}")
    blend = dict(original)
    blend.update({key: (1 - history_weight) * original[key] + history_weight * history[key] for key in ("q90", "q97")})
    return blend, training_rows


def protect_floor(hours, floor):
    """Keep the promise above the floor even after CSV rounding."""
    minimum = np.ceil(np.asarray(floor, dtype=np.float64) * 10000) / 10000
    return np.maximum(np.round(hours, 4), minimum)


def slice_rows(batch, mask):
    return {key: values[mask] for key, values in batch.items()}


def ref_partition(db, cutoff):
    if cutoff is None:
        where = "pay_ts >= TIMESTAMP '2026-08-27'"
        params = ()
    else:
        where = "pay_ts < CAST(? AS TIMESTAMP) AND issue_ts < CAST(? AS TIMESTAMP)"
        params = (cutoff, cutoff)
    return db.execute(f"""
        SELECT hash(pkg_no) % 16 = 0 AS anchor, lgs_company_nm AS carrier
        FROM train WHERE hash(pkg_no) % 8 = 0 AND {where} ORDER BY rid
    """, params).fetchnumpy()


def anchor(db, matched, release, source, name, day):
    reference, model_rows = load_cached(source, name, "ref")
    partition = ref_partition(db, day)
    if not np.array_equal(reference["carrier"], partition["carrier"]):
        raise ValueError(f"Reference rows differ from the database for {name}")
    cutoff = None if day is None else matched.day(day)
    if day is not None:
        # Drop unavailable outcomes even before passing the arrays to calibration.
        reference["y"] = np.where(reference["sign_day"] < cutoff, reference["y"], np.nan)
        eligible = db.execute("""
            SELECT count(*) FROM train
            WHERE pay_ts < CAST(? AS TIMESTAMP) AND sign_ts < CAST(? AS TIMESTAMP)
              AND hash(pkg_no) % 8 <> 0
        """, (day, day)).fetchone()[0]
        if eligible != model_rows:
            raise ValueError(f"Incorrect sign_time eligibility in {name}: {model_rows} != {eligible}")
    pooled, shifts = release.shifts(slice_rows(reference, partition["anchor"]), cutoff)
    return reference, ~partition["anchor"], (pooled, shifts), model_rows


def base_prediction(batch, anchoring, release):
    pooled, shifts = anchoring
    offsets = np.full(len(batch["carrier"]), pooled)
    for group, hours in shifts.items():
        offsets[batch["carrier"] == group] = hours
    return protect_floor(release.base_forecast(batch) + offsets, batch["floor"])


@dataclass
class Period:
    key: str
    group: np.ndarray
    risk: np.ndarray
    floor: np.ndarray
    base: np.ndarray
    y: np.ndarray
    at_least: np.ndarray

    @property
    def known(self):
        return np.isfinite(self.y)


def periods(db, matched, release, source, v3_rules=None):
    ref, tuner, shifts, training_rows = anchor(db, matched, release, source, "fresh", FREEZE)
    cutoff = matched.day(FREEZE)
    promises = base_prediction(ref, shifts, release)
    if v3_rules is not None:
        import carrier_policy

        forecasts = {}
        for group, rule in v3_rules.items():
            recipe = carrier_policy.Candidate(rule["history_weight"], rule["tail_scale"], rule["rule"])
            if recipe not in forecasts:
                variant, _ = load_cached(source, "fresh", "ref", recipe.history_weight)
                variant["y"] = np.where(variant["sign_day"] < cutoff, variant["y"], np.nan)
                forecasts[recipe] = carrier_policy.carrier_base(variant, variant, cutoff, recipe)
            members = ref["carrier"] == int(group)
            promises[members] = forecasts[recipe][members] + rule["buffer"]
        promises = protect_floor(promises, ref["floor"])
    groups = []
    for key, start, end in CALENDAR:
        mask = tuner & (ref["pay_day"] >= matched.day(start)) & (ref["pay_day"] < matched.day(end))
        batch = slice_rows(ref, mask)
        if not len(batch["y"]):
            raise ValueError(f"Missing calibration dates in {key}")
        observed = np.where(np.isfinite(batch["y"]), batch["y"], cutoff * 24 - batch["pay_hour"])
        groups.append(Period(key, batch["carrier"], batch["q97"] - batch["q90"], batch["floor"],
                             promises[mask], batch["y"], observed))
    return groups, training_rows


def risk_edges(calibration, carrier):
    values = np.concatenate([period.risk[period.group == carrier] for period in calibration])
    for quantiles in ((1 / 3, 2 / 3), (.5,)):
        edges = np.unique(np.quantile(values, quantiles))
        if all(np.min(np.bincount(np.searchsorted(edges, p.risk[(p.group == carrier) & p.known], side="right"),
                                  minlength=len(edges) + 1)) >= MIN_SEGMENT for p in calibration):
            return edges.tolist()
    return []


def membership(carriers, risk, family, edges):
    if family == "uniform":
        return np.full(len(carriers), "all", dtype="U16")
    keys = np.empty(len(carriers), dtype="U16")
    for group in np.unique(carriers):
        mask = carriers == group
        cut = edges.get(str(group), []) if family == "risk" else []
        bins = np.searchsorted(cut, risk[mask], side="right")
        keys[mask] = [f"{group}/{number}" for number in bins]
    return keys


def choice_stats(period, rows, group_counts, offsets):
    base, floor = period.base[rows], period.floor[rows]
    known = period.known[rows]
    y, lower = period.y[rows][known], period.at_least[rows]
    group_known, group_all = group_counts
    total_known = int(period.known.sum())
    coeffs = np.empty((5, len(offsets)))
    for i, offset in enumerate(offsets):
        hours = protect_floor(base + offset, floor)
        selected = hours[known]
        coeffs[:, i] = (selected.sum() / total_known,
                        np.count_nonzero(y > selected) / group_known,
                        np.count_nonzero(y - selected > 24) / group_known,
                        np.count_nonzero(lower > hours) / group_all,
                        np.count_nonzero(lower - hours > 24) / group_all)
    return coeffs


def grid(calibration, groups, family, edges, offsets):
    memberships = [membership(period.group, period.risk, family, edges) for period in calibration]
    keys = sorted(set(np.concatenate(memberships)))
    count = len(keys) * len(offsets)
    matrix = np.zeros((len(calibration), len(groups), 5, count))
    slots = {key: slice(i * len(offsets), (i + 1) * len(offsets)) for i, key in enumerate(keys)}
    for t, (period, members) in enumerate(zip(calibration, memberships, strict=True)):
        for index, group in enumerate(groups):
            carrier = period.group == group
            group_counts = int(np.count_nonzero(carrier & period.known)), int(np.count_nonzero(carrier))
            if group_counts[0] == 0:
                raise ValueError(f"No signed records for {group} in {period.key}")
            for key in np.unique(members[carrier]):
                matrix[t, index, :, slots[key]] = choice_stats(period, carrier & (members == key), group_counts, offsets)
    return keys, slots, matrix


def optimize(calibration, keys, slots, matrix, zero_penalty, offsets):
    n_dates, n_groups, _, n_choices = matrix.shape
    width = 1 + n_groups * 2
    n = n_choices + n_dates * width + 1
    objective = np.zeros(n)
    objective[-1] = WORST_WEIGHT
    integrality = np.zeros(n, dtype=int)
    integrality[:n_choices] = 1
    upper = np.full(n, np.inf)
    upper[:n_choices] = 1
    rows, lower, limits = [], [], []

    def row():
        return np.zeros(n)

    def add(coeffs, bound, minimum=-np.inf):
        rows.append(coeffs)
        lower.append(minimum)
        limits.append(bound)

    for key in keys:
        coeffs = row()
        coeffs[slots[key]] = 1
        add(coeffs, 1, minimum=1)
    for date, period in enumerate(calibration):
        mean = float(period.y[period.known].mean())
        me_index = n_choices + date * width
        penalty = slice(me_index + 1, me_index + width)
        score = row()
        score[me_index] = 1
        score[penalty] = 500
        objective += score * (1 - WORST_WEIGHT) / n_dates
        score[-1] = -1
        add(score, 0)
        for sign in (1, -1):
            constraint = row()
            constraint[:n_choices] = sign * matrix[date, :, 0].sum(axis=0)
            constraint[me_index] = -1
            add(constraint, sign * mean)
        if zero_penalty:
            upper[penalty] = 0
        for group in range(n_groups):
            for kind, limit in enumerate(GATE):
                constraint = row()
                constraint[:n_choices] = matrix[date, group, 1 + kind]
                constraint[me_index + 1 + 2 * group + kind] = -1
                add(constraint, limit)
                if zero_penalty:
                    # Extra protection for unsigned orders with a known delay lower bound.
                    confirmed = row()
                    confirmed[:n_choices] = matrix[date, group, 3 + kind]
                    add(confirmed, limit)
    solver = milp(objective, integrality=integrality, bounds=Bounds(0, upper),
                  constraints=LinearConstraint(np.stack(rows), lower, limits),
                  options={"time_limit": 35, "mip_rel_gap": .001})
    if solver.x is None:
        raise ValueError(f"No feasible calibration candidate: {solver.message}")
    shifts = {key: int(offsets[np.argmax(solver.x[slots[key]])]) for key in keys}
    chosen = np.zeros(n_choices)
    for key, offset in shifts.items():
        chosen[slots[key].start + np.searchsorted(offsets, offset)] = 1
    if zero_penalty and (np.any(matrix[:, :, 1:3] @ chosen > np.array(GATE) + 1e-8)
                         or np.any(matrix[:, :, 3:] @ chosen > np.array(GATE) + 1e-8)):
        raise ValueError("The proposed zero-penalty rule exceeds a calibration threshold")
    return shifts, {"status": int(solver.status), "mip_gap": float(solver.mip_gap),
                    "optimizer_objective": float(solver.fun)}


def apply_policy(base, floors, group, risk, policy):
    keys = membership(group, risk, policy["family"], policy["edges"])
    offsets = np.full(len(keys), policy["fallback"], dtype=float)
    for unit, shift in policy["hours"].items():
        offsets[keys == unit] = shift
    return protect_floor(base + offsets, floors), offsets


def tune(project, experiment, v3_adjusted):
    duckdb, matched, release = import_project(project)
    run, cache = locate(project)
    scorer = official_module(cache)
    output = experiment / "v3-adjusted" if v3_adjusted else experiment
    output.mkdir(parents=True, exist_ok=True)
    offsets = V3_OFFSETS if v3_adjusted else OFFSETS
    v3_rules = json.loads((run / "check/summary.json").read_text(encoding="utf-8"))["by_carrier"] if v3_adjusted else None
    with duckdb.connect(str(cache / "features.duckdb"), read_only=True) as db:
        calibration, training_rows = periods(db, matched, release, experiment / "extra", v3_rules)

    groups = sorted(int(g) for g in np.unique(np.concatenate([p.group for p in calibration])))
    edges = {str(g): risk_edges(calibration, g) for g in groups}
    maturity_rows = []
    for period in calibration:
        for group in groups:
            mask = period.group == group
            known = int(np.count_nonzero(mask & period.known))
            maturity_rows.append(dict(window=period.key, carrier=f"LSP_{group:04d}", rows=int(mask.sum()),
                                      known=known, signed_rate=known / int(mask.sum()),
                                      risk_groups=1 + len(edges[str(group)])))
    pd.DataFrame(maturity_rows).to_csv(output / "calibration-maturity.csv", index=False)

    candidates = {}
    score_rows = []
    for family in ("uniform", "carrier", "risk"):
        keys, slots, stats = grid(calibration, groups, family, edges, offsets)
        for goal in ("zero", "min_a"):
            label = f"{family}_{goal}"
            chosen, diagnostics = optimize(calibration, keys, slots, stats, goal == "zero", offsets)
            fallback = (chosen["all"] if family == "uniform" else candidates[f"uniform_{goal}"]["hours"]["all"])
            policy = dict(family=family, goal=goal, edges=edges, hours=chosen, fallback=fallback, **diagnostics)
            for period in calibration:
                hours, _ = apply_policy(period.base, period.floor, period.group, period.risk, policy)
                mask = period.known
                score = scorer.score(period.group[mask], period.y[mask], hours[mask])
                if goal == "zero" and max(score["pen_ontime"], score["pen_severe"]) > 1e-9:
                    raise ValueError(f"Official score contradicts the calibration constraints for {label}")
                score_rows.append(dict(candidate=label, window=period.key, n=int(mask.sum()), **score))
            candidates[label] = policy
            print(f"{label}: {chosen}  (MIP gap {diagnostics['mip_gap']:.3%})", flush=True)

    scoped = dict(freeze=FREEZE, early_cohorts=[list(row) for row in CALENDAR], training_rows=training_rows,
                  min_segment=MIN_SEGMENT, worst_weight=WORST_WEIGHT, strategies=candidates,
                  scorer_sha256=sha256((cache / "official/tools/score.py").read_bytes()).hexdigest())
    if v3_adjusted:
        scoped.update(base="published_v3", offsets=offsets.tolist())
    lock = output / "locked-policy.json"
    staged = lock.with_suffix(".tmp")
    staged.write_text(json.dumps(scoped, indent=2) + "\n", encoding="utf-8")
    staged.replace(lock)
    pd.DataFrame(score_rows).to_csv(output / "calibration-scores.csv", index=False)
    print(f"Locked before evaluation: {lock} [{sha256(lock.read_bytes()).hexdigest()}]", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--experiment", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--v3-adjusted", action="store_true", help="explore bounded adjustments to the published v3 policy")
    args = parser.parse_args()
    tune(args.project.resolve(), args.experiment.resolve(), args.v3_adjusted)


if __name__ == "__main__":
    main()
