"""Time-ordered external check of the F4 quantile and calibration method."""

import argparse
from hashlib import file_digest
import json
from pathlib import Path
import sys
from zipfile import ZipFile

import duckdb
import lightgbm as lgb
import numpy as np
import pandas as pd
from scipy.stats import CensoredData, ecdf


F4_SOURCE = Path(__file__).resolve().parents[1] / "f4-delivery/repro-src"
sys.path.insert(0, str(F4_SOURCE))
from carrier_policy import TARGET_ONTIME, TARGET_TAIL
from release import base_forecast, residual_quantile
from solution import SEED, empirical_quantile


REGION_BASELINE_MIN = 150
REGION_CALIBRATION_MIN = 200
REGION_REPORT_MIN = 100
LATE_TAIL_HOURS = 24.0


def sha256(path):
    with path.open("rb") as file:
        return file_digest(file, "sha256").hexdigest()


def prepare_olist(root):
    path = root / "Olist-Brazilian-Ecommerce.zip"
    with ZipFile(path) as archive:
        def table(name, columns):
            with archive.open(f"olist_{name}_dataset.csv") as file:
                return pd.read_csv(file, usecols=columns)

        orders = table("orders", ["order_id", "customer_id", "order_status", "order_purchase_timestamp",
                                  "order_delivered_customer_date"])
        items = table("order_items", ["order_id", "order_item_id", "product_id", "seller_id", "price", "freight_value"])
        dimensions = ["product_weight_g", "product_length_cm", "product_height_cm", "product_width_cm"]
        products = table("products", ["product_id", "product_category_name", *dimensions])
        customers = table("customers", ["customer_id", "customer_state"])
        sellers = table("sellers", ["seller_id", "seller_state"])

    orders = orders.rename(columns={"order_purchase_timestamp": "start", "order_delivered_customer_date": "end"})
    for col in ("start", "end"):
        orders[col] = pd.to_datetime(orders[col], format="%Y-%m-%d %H:%M:%S", errors="coerce")
    delivered = orders["order_status"].eq("delivered") & orders["start"].notna() & orders["end"].notna()
    frame = orders.loc[delivered, ["order_id", "customer_id", "start", "end"]]
    items = items.merge(products, how="left", on="product_id", validate="many_to_one")
    items = items.merge(sellers, how="left", on="seller_id", validate="many_to_one")
    items = items.sort_values(["order_id", "order_item_id"])
    groups = items.groupby("order_id", sort=False)
    aggregated = groups.agg(
        item_count=("order_item_id", "size"), seller_count=("seller_id", "nunique"),
        item_price=("price", "sum"), freight=("freight_value", "sum"),
        weight=("product_weight_g", "mean"), length=("product_length_cm", "mean"),
        height=("product_height_cm", "mean"), width=("product_width_cm", "mean"),
    ).reset_index()
    first_item = items.drop_duplicates("order_id")[["order_id", "seller_id", "seller_state", "product_category_name"]]
    frame = frame.merge(customers, how="left", on="customer_id", validate="many_to_one")
    frame = frame.merge(aggregated, how="left", on="order_id", validate="one_to_one")
    frame = frame.merge(first_item, how="left", on="order_id", validate="one_to_one")
    frame = frame.rename(columns={"customer_state": "region"})
    frame["same_state"] = frame["region"].eq(frame["seller_state"]).astype(float)
    frame.loc[frame["seller_state"].isna() | frame["region"].isna(), "same_state"] = np.nan
    frame["weekday"] = frame["start"].dt.dayofweek
    info = {"file": path.name, "sha256": sha256(path), "source_rows": len(orders),
            "timed_rows_before_duration_filter": len(frame), "rows_without_items": int(frame["item_count"].isna().sum())}
    categories = ["region", "seller_state", "seller_id", "product_category_name"]
    continuous = ["item_count", "seller_count", "item_price", "freight", "weight", "length", "height", "width",
                  "same_state", "weekday"]
    return frame, info, categories, continuous


def prepare_lade(root):
    path = root / "Cainiao-LaDe-D-Jilin.parquet"
    with duckdb.connect() as db:
        frame = db.execute("""
            SELECT order_id, region_id AS region, courier_id, lng, lat, aoi_id, aoi_type,
                   try_strptime('2000-' || accept_time, '%Y-%m-%d %H:%M:%S') AS start,
                   try_strptime('2000-' || delivery_time, '%Y-%m-%d %H:%M:%S') AS end
            FROM read_parquet(?)
        """, [str(path)]).df()
    timed = frame["start"].notna() & frame["end"].notna()
    info = {"file": path.name, "sha256": sha256(path), "source_rows": len(frame),
            "timed_rows_before_duration_filter": int(timed.sum())}
    return frame.loc[timed].copy(), info, ["region", "courier_id", "aoi_id", "aoi_type"], ["lng", "lat"]


def prepare_splits(frame, info, categories, continuous, date_format):
    duration = (frame["end"] - frame["start"]).dt.total_seconds() / 3600
    valid = np.isfinite(duration) & duration.gt(0)
    info["nonpositive_or_invalid_duration_rows"] = int((~valid).sum())
    frame = frame.loc[valid].assign(actual_hours=duration[valid]).sort_values(["start", "order_id"]).reset_index(drop=True)
    assert frame["order_id"].is_unique
    frame["region"] = frame["region"].astype("string").fillna("unknown")
    frame["hour"] = frame["start"].dt.hour + frame["start"].dt.minute / 60
    frame["month"] = frame["start"].dt.month
    frame["day_of_month"] = frame["start"].dt.day
    features = categories + continuous + ["hour", "month", "day_of_month"]
    assert set(features).isdisjoint({"order_id", "start", "end", "actual_hours", "ds"})
    fit_cut = frame["start"].iloc[int(len(frame) * .60)].normalize()
    test_cut = frame["start"].iloc[int(len(frame) * .80)].normalize()
    early = frame["start"] < fit_cut
    fit = frame.loc[early & frame["end"].lt(fit_cut)]
    middle = frame.loc[~early & frame["start"].lt(test_cut)]
    final = frame.loc[frame["start"].ge(test_cut)]
    assert len(fit) > 0 and len(middle) > 0 and len(final) > 0
    assert len(fit) + len(middle) + len(final) + int(early.sum() - len(fit)) == len(frame)
    assert fit["end"].max() < fit_cut <= middle["start"].min() <= middle["start"].max() < test_cut <= final["start"].min()

    def span(rows):
        return [item.strftime(date_format) for item in (rows["start"].min(), rows["start"].max())]

    info.update(eligible_rows=len(frame), feature_columns=features, fit_days=span(fit), calibration_days=span(middle),
                test_days=span(final), fit_cut=fit_cut.strftime(date_format), test_cut=test_cut.strftime(date_format),
                fit_rows=len(fit), early_not_finished_at_fit_cut=int(early.sum() - len(fit)),
                calibration_rows=len(middle), calibration_completed_at_test_cut=int(middle["end"].lt(test_cut).sum()),
                test_rows=len(final), test_last_end=final["end"].max().strftime(date_format))
    return fit, middle, final, test_cut, features


def matrix(rows, features, category_levels):
    columns = []
    for name in features:
        if name in category_levels:
            levels = category_levels[name]
            known = rows[name].where(rows[name].isin(levels))
            values = pd.Categorical(known, categories=levels).codes.astype(np.float32)
            values[values < 0] = np.nan
        else:
            values = rows[name].to_numpy(dtype=np.float32, na_value=np.nan)
        columns.append(values)
    return np.column_stack(columns)


def forecast_quantiles(fit, to_forecast, features, categories, threads):
    category_levels = {name: fit[name].dropna().unique() for name in categories}
    dataset = lgb.Dataset(matrix(fit, features, category_levels), label=fit["actual_hours"].to_numpy(),
                          feature_name=features, categorical_feature=categories)
    future = matrix(to_forecast, features, category_levels)
    params = {
        "objective": "quantile", "learning_rate": .065, "num_leaves": 47, "min_data_in_leaf": 140, "max_bin": 127,
        "min_data_per_group": 100, "cat_smooth": 45, "feature_fraction": .9, "bagging_fraction": .8, "bagging_freq": 1,
        "seed": SEED, "num_threads": threads, "verbosity": -1, "deterministic": True, "force_col_wise": True,
    }
    predictions = []
    for quantile in (.90, .97):
        model = lgb.train(dict(params, alpha=quantile), dataset, num_boost_round=240)
        predictions.append(np.maximum(0.0001, model.predict(future, num_threads=threads)))
    return predictions


def historical_p90(fit, final):
    pooled = empirical_quantile(fit["actual_hours"].to_numpy(), .90)
    shifts = {}
    for name, rows in fit.groupby("region", sort=False):
        if len(rows) >= REGION_BASELINE_MIN:
            shifts[name] = empirical_quantile(rows["actual_hours"].to_numpy(), .90)
    return final["region"].map(shifts).fillna(pooled).to_numpy(dtype=float)


def calibrated_promise(middle, final, cutoff, base_val, base_test):
    known = middle["end"].lt(cutoff).to_numpy()
    # A package signed after the cutoff contributes only its elapsed-time lower bound.
    elapsed = (cutoff - middle["start"]).dt.total_seconds().to_numpy() / 3600
    observed_residual = middle["actual_hours"].where(known).to_numpy() - base_val
    lower_bound = elapsed - base_val
    regions = middle["region"].to_numpy()

    def estimate(mask):
        observed = observed_residual[mask & known]
        censored = lower_bound[mask & ~known]
        curve = ecdf(CensoredData(uncensored=observed, right=censored) if len(censored) else observed)
        ontime = residual_quantile(curve, observed, TARGET_ONTIME)
        tail = residual_quantile(curve, observed, TARGET_TAIL)
        return float(max(ontime, tail - LATE_TAIL_HOURS)), bool(curve.cdf.probabilities[-1] >= TARGET_TAIL - 1e-12)

    pooled, pooled_tail_identified = estimate(np.ones(len(middle), dtype=bool))
    shifts = {}
    unidentified_groups = 0
    for name in sorted(np.unique(regions)):
        mask = regions == name
        if int(np.count_nonzero(mask & known)) < REGION_CALIBRATION_MIN:
            continue
        group_shift, tail_identified = estimate(mask)
        unidentified_groups += int(not tail_identified)
        weight = mask.sum() / (mask.sum() + 120)
        shifts[name] = float(weight * group_shift + (1 - weight) * pooled)
    applied = final["region"].map(shifts).fillna(pooled).to_numpy(dtype=float)
    prediction = np.maximum(0.0001, base_test + applied)
    return prediction, {"pool_buffer_hours": pooled, "pool_tail_identified": pooled_tail_identified,
                        "region_buffer_hours": shifts, "calibrated_regions_with_unidentified_tail": unidentified_groups,
                        "test_rows_using_pooled": int((~final["region"].isin(shifts)).sum())}


def evaluate(actual, estimate, thresholds):
    assert len(actual) == len(estimate) and np.isfinite(estimate).all() and (estimate > 0).all()
    error = estimate - actual
    absolute = np.abs(error)
    bias = float(error.mean())
    return {"n": len(actual), "mae": float(absolute.mean()), "rmse": float(np.sqrt(np.mean(error ** 2))),
            "median_abs_error": float(np.median(absolute)), "bias": bias, "ME": abs(bias),
            "ontime": float(np.mean(error >= 0)), "severe": float(np.mean(error < -LATE_TAIL_HOURS)),
            "mean_pred": float(estimate.mean()), "mean_actual": float(actual.mean()),
            "within_hours": {str(hours): float(np.mean(absolute <= hours)) for hours in thresholds}}


def run_dataset(key, load, root, threads):
    print(f"[{key}] Preparing labels and evaluation windows", flush=True)
    frame, info, categories, continuous = load(root)
    thresholds = (24, 48) if key == "olist" else (1, 2)
    fit, middle, final, test_cut, features = prepare_splits(
        frame, info, categories, continuous, "%Y-%m-%d" if key == "olist" else "%m-%d",
    )
    print(f"[{key}] Training P90/P97 on {len(fit):,} known labels", flush=True)
    p90, p97 = forecast_quantiles(fit, pd.concat([middle, final], ignore_index=True), features, categories, threads)
    base = base_forecast({"floor": 0.0001, "q90": p90, "q97": p97})
    cut = len(middle)
    calibrated, calibration = calibrated_promise(middle, final, test_cut, base[:cut], base[cut:])
    forecasts = {"historical_p90": historical_p90(fit, final), "p90": p90[cut:], "p97": p97[cut:],
                 "uncalibrated_anchor": base[cut:], "calibrated": calibrated}

    print(f"[{key}] Scoring {len(final):,} later records", flush=True)
    truth = final["actual_hours"].to_numpy()
    metrics = {name: evaluate(truth, predicted, thresholds) for name, predicted in forecasts.items()}
    regions = final["region"].to_numpy()
    group_metrics = {}
    for name in sorted(np.unique(regions)):
        mask = regions == name
        if mask.sum() < REGION_REPORT_MIN:
            continue
        group_metrics[name] = {method: evaluate(truth[mask], forecasts[method][mask], thresholds)
                               for method in ("historical_p90", "uncalibrated_anchor", "calibrated")}
    brief = {key: {m: score[m] for m in ("mae", "ME", "ontime", "severe", "within_hours")}
             for key, score in metrics.items()}
    print(json.dumps(brief, indent=2), flush=True)
    time_diagnostics = {label: {"mean": float(rows["actual_hours"].mean()),
                                "p90": empirical_quantile(rows["actual_hours"].to_numpy(), .90),
                                "p97": empirical_quantile(rows["actual_hours"].to_numpy(), .97)}
                        for label, rows in (("fit", fit), ("calibration", middle), ("holdout", final))}
    return {"data": info, "calibration": calibration, "metrics": metrics, "regions": group_metrics,
            "regions_total": int(final["region"].nunique()), "quantile_cross_rate": float(np.mean(p97[cut:] < p90[cut:])),
            "time_diagnostics": time_diagnostics,
            "holdout_completed_after_last_start_day": int(final["end"].ge(final["start"].max().normalize()+pd.Timedelta(days=1)).sum())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--threads", type=int, default=6)
    args = parser.parse_args()
    results = {name: run_dataset(name, load, args.data, args.threads)
               for name, load in (("olist", prepare_olist), ("lade", prepare_lade))}
    with args.output.open("w", encoding="utf-8") as stream:
        json.dump(results, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(f"Saved aggregate evidence to {args.output}", flush=True)


if __name__ == "__main__":
    main()
