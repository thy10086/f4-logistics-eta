"""Score the supplied F4 historical audit and reproduce its frozen v3 predictions."""

import argparse
import csv
from hashlib import file_digest, sha256
import json
from pathlib import Path
from shutil import copyfileobj
import subprocess
import sys
from time import perf_counter
from zipfile import ZipFile

import duckdb
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = ROOT / "work/f4-terminal-audit/final-rerun/extracted"
RELEASE = ROOT / "outputs/F4-评委复现包.zip"
SCORER_SHA = "13c47c6e8eafab7822171a1e48e75581a471e208017e504393a850c8254b9a45"
EXPECTED_SCORE = {"ME": 83.0517, "B": 83.0517, "A": 83.0517, "pen_ontime": 0.0, "pen_severe": 0.0}
COUNT = 198570


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def member_name(archive, tail):
    name, = [part for part in archive.namelist() if part == tail or part.endswith("/" + tail)]
    return name


def read_header(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return next(csv.reader(handle))


def check_archive(bundle, official, stage, previous):
    begin = perf_counter()
    with ZipFile(bundle) as source:
        assert source.testzip() is None
        for name in ("features.csv", "truth.csv", "predictions.csv"):
            with source.open(name) as data, (stage / name).open("wb") as dest:
                copyfileobj(data, dest)
        bundled_script = source.read("score.py")
    with ZipFile(official) as source:
        original = source.read(member_name(source, "tools/score.py"))
        with source.open(member_name(source, "data/test_202609.csv")) as input_rows:
            expected_fields = next(csv.reader([input_rows.readline().decode("utf-8-sig")]))
    assert bundled_script == original and sha256(original).hexdigest() == SCORER_SHA
    (stage / "score.py").write_bytes(original)
    assert read_header(stage / "features.csv") == expected_fields and len(expected_fields) == 23
    assert read_header(stage / "truth.csv") == ["pkg_no", "lgs_company_nm", "y_total_hours"]
    assert read_header(stage / "predictions.csv") == ["pkg_no", "pred_hours"]
    assert digest(stage / "truth.csv") == digest(previous / "stress_audit_truth.csv")
    assert digest(stage / "predictions.csv") == digest(previous / "stress_audit_prediction.csv")
    print(f"ZIP CRC, original score.py, 23 input fields, and both archived CSVs verified in {perf_counter()-begin:.1f}s", flush=True)
    return expected_fields


def run_score(stage, predictions, output):
    completed = subprocess.run([sys.executable, "-X", "utf8", str(stage / "score.py"),
                                "--truth", str(stage / "truth.csv"), "--pred", str(predictions)],
                               cwd=stage, capture_output=True, encoding="utf-8", check=True)
    output.write_text(completed.stdout, encoding="utf-8")
    points = {key: float(value) for key, value in map(str.split, completed.stdout.splitlines())}
    assert points == EXPECTED_SCORE, points
    print(completed.stdout, end="", flush=True)
    return points


def check_feature_values(stage, original_train, fields):
    start = perf_counter()
    with duckdb.connect(config={"threads": 5, "memory_limit": "2GB"}) as conn:
        sizes = conn.execute("""
            SELECT count(*), count(DISTINCT pkg_no), min(substr(pay_time, 1, 10)), max(substr(pay_time, 1, 10))
            FROM read_csv(?, header=true, all_varchar=true)
        """, [str(stage / "features.csv")]).fetchone()
        assert sizes == (COUNT, COUNT, "2026-09-04", "2026-09-11"), sizes
        columns = [f'f."{field}" IS DISTINCT FROM s."{field}"' for field in fields[1:]]
        mismatches = " OR ".join(columns)
        same_input = conn.execute(f"""
            WITH raw AS (SELECT * FROM read_csv(?, header=true, all_varchar=true)),
                 f AS (SELECT * FROM read_csv(?, header=true, all_varchar=true)),
                 a AS (SELECT * FROM read_csv(?, header=true, all_varchar=true))
            SELECT count(*), count(*) FILTER (WHERE s.pkg_no IS NULL OR a.pkg_no IS NULL),
                   count(*) FILTER (WHERE {mismatches}),
                   count(*) FILTER (WHERE abs(CAST(s.y_total_hours AS DOUBLE) - CAST(a.y_total_hours AS DOUBLE)) > 1e-10
                     OR a.lgs_company_nm IS DISTINCT FROM s.lgs_company_nm)
            FROM f LEFT JOIN raw s USING (pkg_no) LEFT JOIN a USING (pkg_no)
        """, [str(original_train), str(stage / "features.csv"), str(stage / "truth.csv")]).fetchone()
        assert same_input == (COUNT, 0, 0, 0), same_input
    print(f"Compared all {COUNT:,} supplied rows to original F4 training records in {perf_counter()-start:.1f}s", flush=True)


def fit_original_fold(stage, cache, previous):
    for name in ("matched.py", "history_model.py", "carrier_policy.py", "release.py", "adaptive.py", "solution.py"):
        with ZipFile(RELEASE) as review:
            assert review.read(name) == (ARCHIVE / name).read_bytes(), name
    sys.path.insert(0, str(ARCHIVE))
    import matched
    import history_model
    import carrier_policy as policy
    import solution as core

    base = stage / "original"
    history = stage / "history"
    base.mkdir()
    history.mkdir()
    start, end = matched.STRESS_START, matched.STRESS_END
    start_clock = perf_counter()
    with duckdb.connect(str(cache / "features.duckdb"), read_only=True, config={"threads": 6, "memory_limit": "2GB"}) as db:
        overlap = db.execute("""
            SELECT count(*) FROM train JOIN read_csv(?, header=true, all_varchar=true) audit USING (pkg_no)
            WHERE pay_ts < CAST(? AS TIMESTAMP) AND sign_ts < CAST(? AS TIMESTAMP) AND hash(pkg_no) % 8 <> 0
        """, [str(stage / "truth.csv"), start, start]).fetchone()[0]
        assert overlap == 0
        print(f"Fresh v3 training for cutoff {start} with original 240 rounds and seed {core.SEED}", flush=True)
        matched.fit_split(db, base, "stress", start, end, 6, 240)
        snapshots = [history_model.build_snapshot(*history_model.load_series(db, key)) for key in history_model.ENTITY_SQL]
        history_model.run_split(db, history, "stress", start, end, snapshots, 6, 240)
        truth = core.range_frame(db, (start, end))
        mask = policy.audit_masks(db)["stress"]

    variants, fit_count = policy.forecasts(base, history, "stress")
    archive = json.loads((previous / "summary.json").read_text(encoding="utf-8"))
    chosen = archive["by_carrier"]
    assert set(map(int, chosen)) == set(truth.carrier)
    assert np.count_nonzero(mask) == COUNT
    predictions = np.empty(len(truth.x))
    proposals = {}
    for shipper, rule in chosen.items():
        candidate = policy.Candidate(rule["history_weight"], rule["tail_scale"], rule["rule"])
        if candidate not in proposals:
            reference, candidate_target = variants[candidate.history_weight]
            proposals[candidate] = policy.carrier_base(reference, candidate_target, matched.day(start), candidate)
        rows = truth.carrier == int(shipper)
        predictions[rows] = proposals[candidate][rows] + rule["buffer"]
    predictions = core.finalize(predictions, truth.duration_floor)
    path = stage / "retrained-predictions.csv"
    core.export_predictions(path, truth.ids[mask], predictions[mask])
    original_sha = digest(stage / "predictions.csv")
    new_sha = digest(path)
    assert new_sha == original_sha
    print(f"Re-exported 198,570 predictions are byte-identical after {perf_counter()-start_clock:.1f}s", flush=True)
    print(f"Local fitted labels: {fit_count:,}. Prediction SHA-256: {new_sha}", flush=True)
    summary, _ = core.evaluate(truth.y[mask], predictions[mask], truth.carrier_text[mask])
    abs_error = np.abs(truth.y[mask] - predictions[mask])
    return path, dict(**summary, mae=float(abs_error.mean()), within_24h=float((abs_error <= 24).mean()),
                      within_48h=float((abs_error <= 48).mean()), fitted_labels=fit_count, training_overlap=overlap,
                      prediction_sha256=new_sha, fit_seconds=round(perf_counter()-start_clock, 1))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", required=True, type=Path)
    parser.add_argument("--official", required=True, type=Path)
    parser.add_argument("--work", required=True, type=Path)
    args = parser.parse_args()
    stage = args.work.resolve()
    stage.mkdir(parents=True, exist_ok=False)
    prior = ARCHIVE / "f4-full-run"
    cache, = (prior / "cache").iterdir()
    check = prior / "check"
    fields = check_archive(args.bundle, args.official, stage, check)
    print("[Archived prediction score]", flush=True)
    first = run_score(stage, stage / "predictions.csv", stage / "archived-score.txt")
    check_feature_values(stage, cache / "official/data/train_202608_0920.csv", fields)
    new, result = fit_original_fold(stage, cache, check)
    print("[Fresh prediction score]", flush=True)
    second = run_score(stage, new, stage / "retrained-score.txt")
    record = {"archive_sha256": digest(args.bundle), "archived_score": first, "retrained_score": second, "detail": result}
    (stage / "result.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
