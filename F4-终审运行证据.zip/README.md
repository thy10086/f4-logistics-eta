# F4 终审运行证据

`run_receipt.json` 记录最终评委 ZIP、原始题包、原版评分器和正式 CSV 的 SHA-256，及每次调用的命令、起止时间、耗时、退出码和校验结果。执行人为项目工作站上的 Codex。日志内的 `python` 为 Windows x64 的 Python Software Foundation CPython 3.12.10（NuGet 发行版）。

- `final-cold.log` 为新解压最终 ZIP、空项目目录下的完整启动。
- `final-cache.log` 为同一 `full` 命令复用该次冷启动刚生成的项目缓存。
- `final-quick.log` 为新快评目录运行保存的预留预测。
- `locked-csv-check.log` 为对正式 CSV 与官方测试 ID 的独立核验。
- `*_official_score.txt` 由题包原版 `score.py` 直接输出。带 `verified_submission` 的文件记录两个完整入口的预测覆盖与哈希。

三次复评使用训练文件中的带标签记录，均为本地验证。正式测试集标签由主办方保管。队员本人本轮快评的回执单独登记在核验清单。
